// DOM Content Loaded
document.addEventListener("DOMContentLoaded", function() {
    // Initialize all functionality
    initNavigation();
    initScrollEffects();
    initAnimations();
    initFormHandling();
    initProductInteractions();
    initScrollIndicator();
});

// Navigation functionality
function initNavigation() {
    const hamburger = document.querySelector(".hamburger");
    const navMenu = document.querySelector(".nav-menu");
    const navLinks = document.querySelectorAll(".nav-link");
    const navbar = document.querySelector(".navbar");

    // Mobile menu toggle
    hamburger.addEventListener("click", function() {
        hamburger.classList.toggle("active");
        navMenu.classList.toggle("active");
        
        // Animate hamburger bars
        const bars = hamburger.querySelectorAll(".bar");
        if (hamburger.classList.contains("active")) {
            bars[0].style.transform = "rotate(-45deg) translate(-5px, 6px)";
            bars[1].style.opacity = "0";
            bars[2].style.transform = "rotate(45deg) translate(-5px, -6px)";
        } else {
            bars[0].style.transform = "none";
            bars[1].style.opacity = "1";
            bars[2].style.transform = "none";
        }
    });

    // Close mobile menu when clicking on links
    navLinks.forEach(link => {
        link.addEventListener("click", function() {
            hamburger.classList.remove("active");
            navMenu.classList.remove("active");
            
            // Reset hamburger bars
            const bars = hamburger.querySelectorAll(".bar");
            bars[0].style.transform = "none";
            bars[1].style.opacity = "1";
            bars[2].style.transform = "none";
        });
    });

    // Smooth scrolling for navigation links
    navLinks.forEach(link => {
        link.addEventListener("click", function(e) {
            e.preventDefault();
            const targetId = this.getAttribute("href");
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: "smooth"
                });
            }
        });
    });

    // Navbar background on scroll
    window.addEventListener("scroll", function() {
        if (window.scrollY > 100) {
            navbar.style.background = "rgba(255, 255, 255, 0.98)";
            navbar.style.boxShadow = "0 2px 20px rgba(212, 175, 55, 0.1)";
        } else {
            navbar.style.background = "rgba(255, 255, 255, 0.95)";
            navbar.style.boxShadow = "none";
        }
    });

    // Active navigation link highlighting
    window.addEventListener("scroll", function() {
        const sections = document.querySelectorAll("section[id]");
        const scrollPos = window.scrollY + 100;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute("id");
            const navLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);

            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                navLinks.forEach(link => link.classList.remove("active"));
                if (navLink) navLink.classList.add("active");
            }
        });
    });
}

// Scroll effects and animations
function initScrollEffects() {
    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px"
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animatedElements = document.querySelectorAll(".product-card, .benefit-card, .section-header, .about-content, .contact-content");
    animatedElements.forEach(el => {
        el.style.opacity = "0";
        el.style.transform = "translateY(30px)";
        el.style.transition = "opacity 0.6s ease, transform 0.6s ease";
        observer.observe(el);
    });

    // Parallax effect for hero section
    window.addEventListener("scroll", function() {
        const scrolled = window.pageYOffset;
        const heroImage = document.querySelector(".floating-image");
        const heroDecoration = document.querySelector(".image-decoration");
        
        if (heroImage) {
            heroImage.style.transform = `translateY(${scrolled * 0.1}px)`;
        }
        if (heroDecoration) {
            heroDecoration.style.transform = `translateY(${scrolled * 0.15}px) rotate(${scrolled * 0.1}deg)`;
        }
    });
}

// Initialize animations
function initAnimations() {
    // Counter animation for hero stats
    const stats = document.querySelectorAll(".stat-number");
    const statsObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                statsObserver.unobserve(entry.target);
            }
        });
    });

    stats.forEach(stat => {
        statsObserver.observe(stat);
    });

    // Stagger animation for product cards
    const productCards = document.querySelectorAll(".product-card");
    productCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });

    // Stagger animation for benefit cards
    const benefitCards = document.querySelectorAll(".benefit-card");
    benefitCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });
}

// Counter animation function
function animateCounter(element) {
    const text = element.textContent;
    const hasPlus = text.includes("+");
    const number = parseInt(text.replace(/[^\d]/g, ""));
    
    if (isNaN(number)) return;
    
    const duration = 2000;
    const increment = number / (duration / 16);
    let current = 0;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= number) {
            current = number;
            clearInterval(timer);
        }
        
        let displayText = Math.floor(current).toLocaleString();
        if (text.includes("Grade")) {
            displayText = "Grado A";
        } else if (text.includes("%")) {
            displayText = Math.floor(current) + "%";
        } else if (hasPlus) {
            displayText = Math.floor(current).toLocaleString() + "+";
        }
        
        element.textContent = displayText;
    }, 16);
}

// Form handling
function initFormHandling() {
    const contactForm = document.querySelector(".contact-form");
    
    if (contactForm) {
        contactForm.addEventListener("submit", function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // Validate form
            if (validateForm(data)) {
                // Show success message
                showNotification("Grazie per il tuo messaggio! Ti risponderemo presto.", "success");
                
                // Reset form
                this.reset();
                
                // In a real application, you would send the data to a server
                console.log("Modulo inviato:", data);
            }
        });
    }
    
    // Real-time form validation
    const formInputs = document.querySelectorAll(".contact-form input, .contact-form select, .contact-form textarea");
    formInputs.forEach(input => {
        input.addEventListener("blur", function() {
            validateField(this);
        });
        
        input.addEventListener("input", function() {
            if (this.classList.contains("error")) {
                validateField(this);
            }
        });
    });
}

// Form validation
function validateForm(data) {
    let isValid = true;
    const form = document.querySelector(".contact-form");
    
    // Remove previous error messages
    form.querySelectorAll(".error-message").forEach(msg => msg.remove());
    form.querySelectorAll(".error").forEach(field => field.classList.remove("error"));
    
    // Validate name
    if (!data.name || data.name.trim().length < 2) {
        showFieldError("name", "Inserisci un nome valido");
        isValid = false;
    }
    
    // Validate email
    const emailRegex = /^[^
\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!data.email || !emailRegex.test(data.email)) {
        showFieldError("email", "Inserisci un indirizzo email valido");
        isValid = false;
    }
    
    // Validate subject
    if (!data.subject) {
        showFieldError("subject", "Seleziona un oggetto");
        isValid = false;
    }
    
    // Validate message
    if (!data.message || data.message.trim().length < 10) {
        showFieldError("message", "Inserisci un messaggio (almeno 10 caratteri)");
        isValid = false;
    }
    
    return isValid;
}

// Validate individual field
function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = "";
    
    // Remove existing error
    field.classList.remove("error");
    const existingError = field.parentNode.querySelector(".error-message");
    if (existingError) existingError.remove();
    
    switch (field.name) {
        case "name":
            if (value.length < 2) {
                errorMessage = "Il nome deve contenere almeno 2 caratteri";
                isValid = false;
            }
            break;
        case "email":
            const emailRegex = /^[^
\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                errorMessage = "Inserisci un indirizzo email valido";
                isValid = false;
            }
            break;
        case "message":
            if (value.length < 10) {
                errorMessage = "Il messaggio deve contenere almeno 10 caratteri";
                isValid = false;
            }
            break;
    }
    
    if (!isValid) {
        showFieldError(field.name, errorMessage);
    }
    
    return isValid;
}

// Show field error
function showFieldError(fieldName, message) {
    const field = document.querySelector(`[name="${fieldName}"]`);
    if (field) {
        field.classList.add("error");
        
        const errorDiv = document.createElement("div");
        errorDiv.className = "error-message";
        errorDiv.textContent = message;
        errorDiv.style.color = "#e74c3c";
        errorDiv.style.fontSize = "0.9rem";
        errorDiv.style.marginTop = "5px";
        
        field.parentNode.appendChild(errorDiv);
    }
}

// Product interactions
function initProductInteractions() {
    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll(".product-btn");
    addToCartButtons.forEach(button => {
        button.addEventListener("click", function(e) {
            e.preventDefault();
            
            const productCard = this.closest(".product-card");
            const productTitle = productCard.querySelector(".product-title").textContent;
            const productPrice = productCard.querySelector(".price").textContent;
            
            // Add visual feedback
            this.style.transform = "scale(0.95)";
            setTimeout(() => {
                this.style.transform = "scale(1)";
            }, 150);
            
            // Show notification
            showNotification(`${productTitle} aggiunto al carrello!`, "success");
            
            // In a real application, you would add the item to a cart
            console.log("Aggiunto al carrello:", { title: productTitle, price: productPrice });
        });
    });
    
    // Product card hover effects
    const productCards = document.querySelectorAll(".product-card");
    productCards.forEach(card => {
        card.addEventListener("mouseenter", function() {
            this.style.transform = "translateY(-10px) scale(1.02)";
        });
        
        card.addEventListener("mouseleave", function() {
            this.style.transform = "translateY(0) scale(1)";
        });
    });
}

// Scroll indicator functionality
function initScrollIndicator() {
    const scrollIndicator = document.querySelector(".scroll-indicator");
    
    if (scrollIndicator) {
        scrollIndicator.addEventListener("click", function() {
            const productsSection = document.querySelector("#products");
            if (productsSection) {
                const offsetTop = productsSection.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: "smooth"
                });
            }
        });
        
        // Hide scroll indicator after scrolling
        window.addEventListener("scroll", function() {
            if (window.scrollY > 200) {
                scrollIndicator.style.opacity = "0";
                scrollIndicator.style.pointerEvents = "none";
            } else {
                scrollIndicator.style.opacity = "1";
                scrollIndicator.style.pointerEvents = "auto";
            }
        });
    }
}

// Notification system
function showNotification(message, type = "info") {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll(".notification");
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement("div");
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    Object.assign(notification.style, {
        position: "fixed",
        top: "20px",
        right: "20px",
        padding: "15px 20px",
        borderRadius: "8px",
        color: "white",
        fontWeight: "500",
        zIndex: "10000",
        transform: "translateX(100%)",
        transition: "transform 0.3s ease",
        maxWidth: "300px",
        wordWrap: "break-word"
    });
    
    // Set background color based on type
    switch (type) {
        case "success":
            notification.style.background = "#27ae60";
            break;
        case "error":
            notification.style.background = "#e74c3c";
            break;
        default:
            notification.style.background = "#3498db";
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = "translateX(0)";
    }, 100);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
        notification.style.transform = "translateX(100%)";
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 4000);
    
    // Click to dismiss
    notification.addEventListener("click", function() {
        this.style.transform = "translateX(100%)";
        setTimeout(() => {
            if (this.parentNode) {
                this.parentNode.removeChild(this);
            }
        }, 300);
    });
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Smooth scroll polyfill for older browsers
if (!("scrollBehavior" in document.documentElement.style)) {
    const smoothScrollPolyfill = function(target, duration = 1000) {
        const targetPosition = target.offsetTop - 80;
        const startPosition = window.pageYOffset;
        const distance = targetPosition - startPosition;
        let startTime = null;
        
        function animation(currentTime) {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const run = ease(timeElapsed, startPosition, distance, duration);
            window.scrollTo(0, run);
            if (timeElapsed < duration) requestAnimationFrame(animation);
        }
        
        function ease(t, b, c, d) {
            t /= d / 2;
            if (t < 1) return c / 2 * t * t + b;
            t--;
            return -c / 2 * (t * (t - 2) - 1) + b;
        }
        
        requestAnimationFrame(animation);
    };
    
    // Override smooth scroll for older browsers
    document.querySelectorAll(".nav-link").forEach(link => {
        link.addEventListener("click", function(e) {
            e.preventDefault();
            const targetId = this.getAttribute("href");
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                smoothScrollPolyfill(targetSection);
            }
        });
    });
}

// Performance optimization: Lazy load images
function initLazyLoading() {
    const images = document.querySelectorAll("img[data-src]");
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove("lazy");
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Initialize lazy loading if needed
if (document.querySelectorAll("img[data-src]").length > 0) {
    initLazyLoading();
}

// Add CSS for error states
const errorStyles = document.createElement("style");
errorStyles.textContent = `
    .form-group input.error,
    .form-group select.error,
    .form-group textarea.error {
        border-color: #e74c3c;
        box-shadow: 0 0 0 3px rgba(231, 76, 60, 0.1);
    }
    
    .error-message {
        color: #e74c3c;
        font-size: 0.9rem;
        margin-top: 5px;
    }
    
    .nav-link.active {
        color: var(--primary-color);
    }
    
    .nav-link.active::after {
        width: 100%;
    }
`;
document.head.appendChild(errorStyles);

